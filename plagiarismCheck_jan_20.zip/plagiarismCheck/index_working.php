<?php
	if (isset($_REQUEST['jsondata'])) {
		echo $_REQUEST['jsondata'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Plagiarism Checker</title>
	<link href = "assets/css/bootstrap.css" rel="stylesheet" media="screen">
	<script src = "assets/js/jquery.js"></script>
	<script src = "assets/js/bootstrap.min.js"></script>
	<script src="//unpkg.com/string-similarity/umd/string-similarity.min.js"></script>
</head>
<body>
	<form id="CheckPlag" method="POST" >
		<label for="fname">String:</label><br>

		<textarea name="query" id="query"></textarea></br>
		<!-- <input type="" name=""> -->
		<input type="file" accept="text/plain" name="uploadfile">
		<input type="submit" value="Submit">
	</form>
</body>
<script type="text/javascript">
	// console.log(stringSimilarity.compareTwoStrings("This tool has the ability to check plagiarism by matching your content against billions of webpages on the Internet", "This tool has the ability to check plagiarism by matching your content against billions of webpages on the Internet. Once you upload your content, it will automatically run it against every existing content on the web within seconds, making it the most sophisticated yet fastest plagiarism scanner you'll ever come across in your lifetime."));


	$( "#CheckPlag" ).submit(function( event ) {
		// alert( "Handler for .submit() called." );
		var query=$('#query').val();
		var strlen = query.split('.');
		var countword = $.trim($('#query').val()).split(" ");
        console.log();
		if (countword.length>20) {
			getResp(query, strlen[0], 0);
		}else{
			alert("Need More Data for Plag");
		}
		
		// strlen.forEach(getResp);
	 	event.preventDefault();
	});
	function getResp(oristr, query, i){
		$.ajax({
			url:'https://customsearch.googleapis.com/customsearch/v1?key=AIzaSyB9ngn9ZcB4eNumFyQ3db0Bt5hJXyiGTQY&cx=998bf1711fc0eef2d&q='+query,
			method:"GET",
			success: function(data){
				if(data["searchInformation"]["totalResults"] != 0){
					var strlen = oristr.split('.');
					// strlen.forEach(getPlag);
					strlen.forEach(function(STR) {
					    var simper = data["items"][0]["snippet"].localeCompare(STR);
					    // console.log(data["items"][i]["snippet"]);
						console.log(STR);
						var res = stringSimilarity.findBestMatch(STR, [
							data["items"][0]["snippet"],
							data["items"][1]["snippet"],
							data["items"][2]["snippet"]
						]);
						console.log(res);
					});
					event.preventDefault();
				}
			}
		});
	}

	let input = document.querySelector('input') 

	let textarea = document.querySelector('textarea') 

	// This event listener has been implemented to identify a 
	// Change in the input section of the html code 
	// It will be triggered when a file is chosen. 
	input.addEventListener('change', () => { 
	    let files = input.files; 

	    if (files.length == 0) return; 

	    /* If any further modifications have to be made on the 
	       Extracted text. The text can be accessed using the  
	       file variable. But since this is const, it is a read  
	       only variable, hence immutable. To make any changes,  
	       changing const to var, here and In the reader.onload  
	       function would be advisible */
	    const file = files[0]; 

	    let reader = new FileReader(); 

	    reader.onload = (e) => { 
	        const file = e.target.result; 
	        // This is a regular expression to identify carriage  
	        // Returns and line breaks 
	        const lines = file.split(/\r\n|\n/);
	        textarea.value = lines.join('\n');
	    };
	  
	    reader.onerror = (e) => alert(e.target.error.name); 
	  
	    reader.readAsText(file); 
	}); 
	// httpGet("https://sridix.com");
	// function httpGet(theUrl)
	// {
	//     if (window.XMLHttpRequest)
	//     {// code for IE7+, Firefox, Chrome, Opera, Safari
	//         xmlhttp=new XMLHttpRequest();
	//     }
	//     else
	//     {// code for IE6, IE5
	//         xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	//     }
	//     xmlhttp.onreadystatechange=function()
	//     {
	//         if (xmlhttp.readyState==4 && xmlhttp.status==200)
	//         {
	//         	console.log(xmlhttp.responseText);
	//             return xmlhttp.responseText;
	//         }
	//     }
	//     xmlhttp.open("GET", theUrl, false );
	//     xmlhttp.send();    
	// }


	function url_content(url){
	    return $.get(url);
	}
	url_content("https://sridix.com").success(function(data){ 
		// console.log(data);
		var data1 = data.split('<body>');
		console.log(data1);
		// document.write(removeTags(data));
	});


	// var xmlhttp, text;
	// xmlhttp = new XMLHttpRequest();
	// xmlhttp.open('GET', 'http://www.example.com/file.txt', false);
	// xmlhttp.send();
	// text = xmlhttp.responseText;

	// $( "#CheckPlag" ).submit(function( event ) {
	// 	// alert( "Handler for .submit() called." );
	// 	var query=$('#query').val();
	// 	var strlen = query.split('.');
	// 	// console.log(strlen);
	// 	getResp(query, 0);
	// 	// strlen.forEach(getResp);
	//  	event.preventDefault();
	// });
	// function getResp(query, i){
	// 	// console.log(query);
	// 	$.ajax({
	// 		url:'https://www.googleapis.com/customsearch/v1?key=AIzaSyDUWY9npmAwNxNwmkb6NuTicKQnoM9fgFM&cx=aedd485fc0bf679c0&q='+query,
	// 		method:"GET",
	// 		success: function(data){
	// 			if(data["searchInformation"]["totalResults"] != 0){
	// 				var res = stringSimilarity.findBestMatch(query, [
	// 					data["items"][0]["snippet"],
	// 					data["items"][1]["snippet"],
	// 					data["items"][2]["snippet"]
	// 				]);
	// 				console.log("Text: " + query);
	// 				console.log(res);
	// 			}else{
	// 				console.log("Text: " + query);
	// 				console.log("unique");
	// 			}
	// 		},
	// 		error: function(error){
	// 			console.log(error);
	// 		}
	// 	});
	// }
	
</script>
<script> 
function removeTags(str) { 
    if ((str===null) || (str==='')) 
        return false; 
    else
        str = str.toString(); 
          
    // Regular expression to identify HTML tags in  
    // the input string. Replacing the identified  
    // HTML tag with a null string. 
    return str.replace( /(<([^>]+)>)/ig, ''); 
} 
</script>   
</html>
